import os
import torch
import nibabel as nib
import numpy as np
from glob import glob
from torch.utils.data import Dataset, DataLoader, random_split


def center_crop_3d(volume, crop_size):
    """Crop a 3D tensor (C, D, H, W) to the given crop_size (cd, ch, cw)."""
    _, D, H, W = volume.shape
    cd, ch, cw = crop_size
    d1 = max((D - cd) // 2, 0)
    h1 = max((H - ch) // 2, 0)
    w1 = max((W - cw) // 2, 0)
    return volume[:, d1:d1+cd, h1:h1+ch, w1:w1+cw]


class EFieldDataset(Dataset):
    def __init__(self, dadt_files, cond_files, efield_files, transform=None):
        self.dadt_files   = dadt_files
        self.cond_files   = cond_files
        self.efield_files = efield_files
        self.transform    = transform

        # Sanity check — all lists must be the same length
        assert len(self.dadt_files) == len(self.cond_files) == len(self.efield_files), \
            f"File list length mismatch: dadt={len(self.dadt_files)}, " \
            f"cond={len(self.cond_files)}, efield={len(self.efield_files)}"

    def __len__(self):
        return len(self.dadt_files)

    def load_nifti(self, path):
        data = nib.load(path).get_fdata()
        data = np.nan_to_num(data)
        return data.astype(np.float32)

    def __getitem__(self, idx):
        dadt   = self.load_nifti(self.dadt_files[idx])
        cond   = self.load_nifti(self.cond_files[idx])
        efield = self.load_nifti(self.efield_files[idx])

        # Rearrange axes: from (D, H, W, C) to (C, D, H, W)
        dadt   = torch.from_numpy(dadt).permute(3, 0, 1, 2)    # (3, D, H, W)
        cond   = torch.from_numpy(np.squeeze(cond)).unsqueeze(0) # (1, D, H, W)
        efield = torch.from_numpy(efield).permute(3, 0, 1, 2)  # (3, D, H, W)

        # Center crop to fixed 128^3
        crop_size = (128, 128, 128)
        dadt   = center_crop_3d(dadt,   crop_size)
        cond   = center_crop_3d(cond,   crop_size)
        efield = center_crop_3d(efield, crop_size)

        if self.transform:
            dadt, cond, efield = self.transform((dadt, cond, efield))

        return (dadt, cond), efield


def make_dataloaders(dadt_dir, cond_dir, efield_dir,
                     batch_size=4, num_workers=8, split_ratio=0.8):
    """
    Build train and validation DataLoaders.

    Files are matched by subject ID extracted from the dadt filename:
        <subject_id>_D.nii.gz       → dadt
        <subject_id>_conductivity.nii.gz → cond
        <subject_id>_E.nii.gz       → efield

    Only subjects with all three files present are included.
    """
    dadt_files = sorted(glob(os.path.join(dadt_dir, '*_D.nii.gz')))

    if len(dadt_files) == 0:
        raise FileNotFoundError(f"No dadt files found in {dadt_dir}")

    matched_dadt, matched_cond, matched_efield = [], [], []
    missing = []

    for dadt_path in dadt_files:
        subject_id  = os.path.basename(dadt_path).replace('_D.nii.gz', '')
        cond_path   = os.path.join(cond_dir,   f"{subject_id}_conductivity.nii.gz")
        efield_path = os.path.join(efield_dir, f"{subject_id}_E.nii.gz")

        if os.path.exists(cond_path) and os.path.exists(efield_path):
            matched_dadt.append(dadt_path)
            matched_cond.append(cond_path)
            matched_efield.append(efield_path)
        else:
            missing.append(subject_id)

    if missing:
        print(f"[WARNING] {len(missing)} subjects missing cond or efield files. "
              f"First few: {missing[:5]}")

    print(f"[INFO] Matched {len(matched_dadt)} complete samples "
          f"({len(missing)} skipped)")

    if len(matched_dadt) == 0:
        raise RuntimeError("No complete samples found. Check file naming and directories.")

    dataset   = EFieldDataset(matched_dadt, matched_cond, matched_efield)
    train_len = int(len(dataset) * split_ratio)
    val_len   = len(dataset) - train_len

    # Fixed seed ensures same split across runs for reproducibility
    train_set, val_set = random_split(
        dataset, [train_len, val_len],
        generator=torch.Generator().manual_seed(42)
    )

    print(f"[INFO] Train samples: {train_len} | Val samples: {val_len}")

    train_loader = DataLoader(
        train_set,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        persistent_workers=True
    )
    val_loader = DataLoader(
        val_set,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        persistent_workers=True
    )

    return train_loader, val_loader
