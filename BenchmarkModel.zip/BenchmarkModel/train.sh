#!/bin/bash -l
#SBATCH --nodes=1
#SBATCH --gres=gpu:1
#SBATCH --time=12:00:00
#SBATCH --partition=gpu
#SBATCH --account=pawsey1242-gpu
#SBATCH --output=train_%j.out
#SBATCH --error=train_%j.err

module load singularity/4.1.0-nompi

export myRepository=$MYSOFTWARE/singularity/myRepository
export containerImage=$myRepository/simnibs_4.5.0.sif
export mycommand=$MYSCRATCH/Thesis/SlicerTMS-PINN-Model/newTrain.py

srun --nodes=1 --ntasks=1 --cpus-per-task=8 \
     --gpus-per-task=1 --gpu-bind=closest \
     singularity exec --nv ${containerImage} python ${mycommand}
